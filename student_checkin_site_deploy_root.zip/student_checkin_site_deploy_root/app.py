import sqlite3
import os
from pathlib import Path
from datetime import datetime
from flask import Flask, g, render_template, request, redirect, url_for, session, flash
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "data.db"

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "replace-this-with-random-secret")


def hash_password(raw: str) -> str:
    return generate_password_hash(raw, method="pbkdf2:sha256")


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


def ensure_bootstrap_data():
    db = get_db()
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_no TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            class_name TEXT,
            dorm TEXT,
            phone TEXT,
            wechat TEXT,
            password_hash TEXT NOT NULL
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS checkins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            month TEXT NOT NULL,
            absent_count INTEGER NOT NULL DEFAULT 0,
            late_count INTEGER NOT NULL DEFAULT 0,
            failed_count INTEGER NOT NULL DEFAULT 0,
            mood_alert_count INTEGER NOT NULL DEFAULT 0,
            dorm_status TEXT,
            stress_level TEXT,
            need_talk TEXT,
            note TEXT,
            risk_score INTEGER NOT NULL,
            risk_level TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY (student_id) REFERENCES students(id)
        )
        """
    )

    has_teacher = db.execute(
        "SELECT 1 FROM users WHERE username='teacher' AND role='teacher' LIMIT 1"
    ).fetchone()
    if not has_teacher:
        teacher_password = os.getenv("TEACHER_INIT_PASSWORD", "admin123")
        db.execute(
            "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
            ("teacher", hash_password(teacher_password), "teacher"),
        )
    db.commit()


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


@app.before_request
def prepare_database():
    ensure_bootstrap_data()


def calculate_level(absent, late, failed, mood):
    score = absent * 4 + late * 2 + failed * 5 + mood * 6
    if score >= 20:
        return score, "一级"
    if score >= 12:
        return score, "二级"
    if score >= 6:
        return score, "三级"
    return score, "正常"


def require_teacher():
    return session.get("role") == "teacher"


def require_student():
    return session.get("role") == "student"


@app.route("/")
def home():
    if require_teacher():
        return redirect(url_for("teacher_dashboard"))
    if require_student():
        return redirect(url_for("student_form"))
    return render_template("home.html")


@app.route("/teacher/login", methods=["GET", "POST"])
def teacher_login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        teacher = db.execute(
            "SELECT * FROM users WHERE username=? AND role='teacher'", (username,)
        ).fetchone()
        if teacher and check_password_hash(teacher["password_hash"], password):
            session.clear()
            session["role"] = "teacher"
            session["user_id"] = teacher["id"]
            return redirect(url_for("teacher_dashboard"))
        flash("账号或密码错误")
    return render_template("teacher_login.html")


@app.route("/student/login", methods=["GET", "POST"])
def student_login():
    if request.method == "POST":
        student_no = request.form.get("student_no", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        student = db.execute(
            "SELECT * FROM students WHERE student_no=?", (student_no,)
        ).fetchone()
        if student and check_password_hash(student["password_hash"], password):
            session.clear()
            session["role"] = "student"
            session["student_id"] = student["id"]
            session["student_no"] = student["student_no"]
            return redirect(url_for("student_form"))
        flash("学号或密码错误")
    return render_template("student_login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))


@app.route("/student/form", methods=["GET", "POST"])
def student_form():
    if not require_student():
        return redirect(url_for("student_login"))

    db = get_db()
    student = db.execute(
        "SELECT * FROM students WHERE id=?", (session["student_id"],)
    ).fetchone()

    if request.method == "POST":
        month = request.form.get("month", "").strip()
        absent = int(request.form.get("absent_count", 0))
        late = int(request.form.get("late_count", 0))
        failed = int(request.form.get("failed_count", 0))
        mood = int(request.form.get("mood_alert_count", 0))
        dorm = request.form.get("dorm_status", "").strip()
        stress = request.form.get("stress_level", "").strip()
        need_talk = request.form.get("need_talk", "否").strip()
        note = request.form.get("note", "").strip()

        score, level = calculate_level(absent, late, failed, mood)
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        db.execute(
            """
            INSERT INTO checkins (
                student_id, month, absent_count, late_count, failed_count,
                mood_alert_count, dorm_status, stress_level, need_talk,
                note, risk_score, risk_level, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                student["id"], month, absent, late, failed, mood,
                dorm, stress, need_talk, note, score, level, now,
            ),
        )
        db.commit()
        flash(f"提交成功，当前预警等级：{level}")
        return redirect(url_for("student_form"))

    recent = db.execute(
        "SELECT month, risk_score, risk_level, created_at FROM checkins WHERE student_id=? ORDER BY id DESC LIMIT 5",
        (student["id"],),
    ).fetchall()
    return render_template("student_form.html", student=student, recent=recent)


@app.route("/teacher/dashboard")
def teacher_dashboard():
    if not require_teacher():
        return redirect(url_for("teacher_login"))

    db = get_db()
    rows = db.execute(
        """
        SELECT s.student_no, s.name, s.class_name, c.month, c.absent_count, c.late_count,
               c.failed_count, c.mood_alert_count, c.need_talk, c.risk_score, c.risk_level,
               c.created_at
        FROM checkins c
        JOIN students s ON c.student_id = s.id
        ORDER BY c.id DESC
        """
    ).fetchall()

    stats = {
        "一级": sum(1 for r in rows if r["risk_level"] == "一级"),
        "二级": sum(1 for r in rows if r["risk_level"] == "二级"),
        "三级": sum(1 for r in rows if r["risk_level"] == "三级"),
        "正常": sum(1 for r in rows if r["risk_level"] == "正常"),
    }
    return render_template("teacher_dashboard.html", rows=rows, stats=stats)


@app.route("/teacher/students")
def teacher_students():
    if not require_teacher():
        return redirect(url_for("teacher_login"))
    db = get_db()
    students = db.execute(
        "SELECT student_no, name, class_name, dorm, phone, wechat FROM students ORDER BY student_no"
    ).fetchall()
    return render_template("teacher_students.html", students=students)


@app.route("/teacher/add-student", methods=["GET", "POST"])
def teacher_add_student():
    if not require_teacher():
        return redirect(url_for("teacher_login"))

    if request.method == "POST":
        db = get_db()
        student_no = request.form.get("student_no", "").strip()
        name = request.form.get("name", "").strip()
        class_name = request.form.get("class_name", "").strip()
        dorm = request.form.get("dorm", "").strip()
        phone = request.form.get("phone", "").strip()
        wechat = request.form.get("wechat", "").strip()
        init_password = request.form.get("init_password", "123456").strip() or "123456"

        db.execute(
            """
            INSERT INTO students (student_no, name, class_name, dorm, phone, wechat, password_hash)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                student_no, name, class_name, dorm, phone, wechat,
                hash_password(init_password),
            ),
        )
        db.commit()
        flash("学生已添加")
        return redirect(url_for("teacher_students"))

    return render_template("teacher_add_student.html")


if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=False)
