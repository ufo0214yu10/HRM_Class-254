#!/usr/bin/env sh
set -eu

python -m pip install --no-cache-dir -r requirements.txt
