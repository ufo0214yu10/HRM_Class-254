# 班主任学生月报系统（可云部署）

## 功能
- 学生每月1-2次自填（缺勤、晚归、挂科、情绪、宿舍近况等）
- 自动计算风险分并分类：一级/二级/三级/正常
- 仅班主任可查看全班汇总与学生信息
- 学生仅可登录并查看/提交自己的数据

## 云端部署（Railway）
1. 优先只上传 `student_checkin_site` 这个目录到 GitHub 仓库根目录。
2. 在 Railway 新建项目，选择该仓库。
3. 确保仓库根目录能看到：`app.py`、`requirements.txt`、`Procfile`、`Dockerfile`。
4. 在 Railway Variables 设置：
- `SECRET_KEY`：长随机字符串
- `TEACHER_INIT_PASSWORD`：班主任初始密码
5. 部署完成后，Railway 会给公网 URL

## 如果你上传的是外层文件夹
外层也已经放了 `Dockerfile` 和 `railway.toml`，Railway 可以从外层构建，但更推荐只上传 `student_checkin_site`，更清爽。

## 本地运行（可选）
1. 安装依赖：`pip install -r requirements.txt`
2. 初始化数据库：`python init_db.py`
3. 启动：`python app.py`
4. 打开：`http://127.0.0.1:5000`

## 账号说明
- 班主任账号固定：`teacher`
- 班主任密码：首次由 `TEACHER_INIT_PASSWORD` 决定
- 学生账号：学号
- 学生密码：创建学生时设置

## 隐私说明
- 学生信息与全量记录只在班主任后台显示
- 学生端无法访问班主任页面
