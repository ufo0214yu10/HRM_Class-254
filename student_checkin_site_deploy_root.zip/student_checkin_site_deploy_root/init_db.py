import sqlite3
from pathlib import Path
from werkzeug.security import generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / 'data.db'

SCHEMA = '''
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS checkins;

CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL
);

CREATE TABLE students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_no TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    class_name TEXT,
    dorm TEXT,
    phone TEXT,
    wechat TEXT,
    password_hash TEXT NOT NULL
);

CREATE TABLE checkins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    month TEXT NOT NULL,
    absent_count INTEGER NOT NULL DEFAULT 0,
    late_count INTEGER NOT NULL DEFAULT 0,
    failed_count INTEGER NOT NULL DEFAULT 0,
    mood_alert_count INTEGER NOT NULL DEFAULT 0,
    dorm_status TEXT,
    stress_level TEXT,
    need_talk TEXT,
    note TEXT,
    risk_score INTEGER NOT NULL,
    risk_level TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (student_id) REFERENCES students(id)
);
'''

seed_students = [
    ('20252593', '包小于', '2025级工商人力4班', '19号公寓-523', '15215058167', 'xiaoyuerere', '123456'),
    ('20252601', '成文溪', '2025级工商人力4班', '19号公寓-519', '18047216101', 'wxid_9mk62vx12ty022', '123456'),
    ('20252603', '樊可可', '2025级工商人力4班', '19号公寓-519', '17395468305', 'fan2301938029', '123456'),
]


def hash_password(raw: str) -> str:
    return generate_password_hash(raw, method="pbkdf2:sha256")


def main():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.executescript(SCHEMA)

    cur.execute(
        'INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)',
        ('teacher', hash_password('admin123'), 'teacher'),
    )

    for s in seed_students:
        cur.execute(
            '''
            INSERT INTO students (student_no, name, class_name, dorm, phone, wechat, password_hash)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ''',
            (s[0], s[1], s[2], s[3], s[4], s[5], hash_password(s[6])),
        )

    conn.commit()
    conn.close()
    print(f'数据库已初始化: {DB_PATH}')
    print('班主任账号: teacher / admin123')
    print('学生默认密码: 123456（可后续扩展修改密码功能）')


if __name__ == '__main__':
    main()
